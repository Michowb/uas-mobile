package com.example.micho_3122101247

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
